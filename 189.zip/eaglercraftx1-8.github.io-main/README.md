# EaglerCraftX-1.8
EaglerCraftX Client for 1.8
  
**I am not affiliated with or employed by EaglerCraft or Eagtek. I solely host these sites. I do not own or work for EaglerCraft and am not affiliated with Mojang.**  
  
### Links:
- [Cloudflare Pages Hosted](https://eaglercraftx1-8.pages.dev/) (https://eaglercraftx1-8.pages.dev/)
- [Github Pages Hosted](https://eaglercraftx1-8.github.io/) (https://eaglercraftx1-8.github.io/)
- [Netlify Hosted](https://eaglercraftx1-8.netlify.app/) (https://eaglercraftx1-8.netlify.app/) [![Netlify Status](https://api.netlify.com/api/v1/badges/12060eea-2a19-4da5-82ea-c6015722249e/deploy-status)](https://app.netlify.com/sites/eaglercraftx1-8/deploys)
- [Render Hosted](https://eaglercraftx1-8.onrender.com/) (https://eaglercraftx1-8.onrender.com/)
- [eagler-empire.com Hosted (Cloudflare Pages)](https://webclientadvanced.eagler-empire.com/) (https://webclientadvanced.eagler-empire.com/)
