# 1.8.9
**New Eaglercraft 1.8.9 Client! Reborn after old 1.8.9 got DMCA'd :(**

# WAIT! Mojang, if you are willing to violently DMCA this, please read BtPlayzX's message on this website: https://github.com/EaglerDevs/Dear-Mojang-via-Eaglercraft/tree/master
